/**
 * VideoPro Edit v2.0 - Real Moving Video & Audio Studio Player Engine
 * Always plays REAL moving H.264 MP4 video inside <video id="main-video"> (never static pictures!).
 * Synchronizes full duration (e.g. 09:04 = 544s), real audio stream / spoken Arabic voice audio,
 * live subtitles, timeline scrubbing, splitting, 9:16 reframe, speed, jump-cut, and color filters.
 */
class VideoPlayer {
  constructor(videoEl) {
    this.video = videoEl;
    this.isPlaying = false;
    this.isSynthesizedPlatformStream = false;
    this.isChromelessStream = false;
    this.ytPlayer = null;
    this.ytPollTimer = null;
    this.ytVideoId = null;
    this.virtualCurrentTime = 0;
    this.virtualDuration = 0;
    this.playbackSpeed = 1.0;
    this.previewSegmentBounds = null;
    this.jumpCutSegments = null;
    this.sceneImages = [];
    this.candidateMp4Urls = [];
    this.directAudioUrl = "";
    this.currentSourceIndex = 0;
    this.videoTitle = "";
    this.videoUploader = "";
    this.isShortVideo = false;
    this.fallbackBlobUrl = "";
    this.rafId = null;
    this.lastTickMs = 0;
    this.lastSpokenCueId = -1;

    // Dedicated audio elements for original YouTube audio stream or Google Arabic TTS MP3 stream
    this.ytAudioEl = null;
    this.ttsAudioEl = null;

    this.centerPlayBtn = document.getElementById("center-play-btn");
    this.timelinePlayBtn = document.getElementById("timeline-play-btn");
    this.timeDisplay = document.getElementById("player-time-display");
    this.volumeBtn = document.getElementById("player-volume-btn");
    this.volumeSlider = document.getElementById("player-volume-slider");
    this.volumeIcon = document.getElementById("volume-icon");
    this.fullscreenBtn = document.getElementById("player-fullscreen-btn");
    this.settingsBtn = document.getElementById("player-settings-btn");
    this.qualityBadge = document.getElementById("player-quality-badge");
    this.sourceSwitchBtn = document.getElementById("player-source-switch-btn");
    this.sourceLabel = document.getElementById("player-source-label");
    this.subtitlesOverlay = document.getElementById("player-subtitles-overlay");

    this.filters = {
      brightness: 1.0,
      contrast: 1.0,
      saturation: 1.0,
      sepia: 0,
      blur: 0,
    };

    this.previousVolume = 1.0;
    this.init();
  }

  init() {
    if (this.timeDisplay) {
      this.timeDisplay.setAttribute("dir", "ltr");
    }

    document.getElementById("player-delete-video-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (window.deleteCurrentVideo) {
        window.deleteCurrentVideo();
      }
    });

    if (this.sourceSwitchBtn) {
      this.sourceSwitchBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.cycleStreamSource();
      });
    }

    document.getElementById("empty-state-upload-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      document.getElementById("video-file-input")?.click();
    });
    document.getElementById("empty-player-state")?.addEventListener("click", (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "BUTTON") return;
      document.getElementById("video-file-input")?.click();
    });

    if (!window.currentVideoId) {
      this.showEmptyState();
    }

    if (this.centerPlayBtn) {
      this.centerPlayBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.togglePlay();
      });
    }
    if (this.timelinePlayBtn) {
      this.timelinePlayBtn.addEventListener("click", () => this.togglePlay());
    }
    if (this.video) {
      this.video.addEventListener("click", () => this.togglePlay());
    }

    this.video.addEventListener("play", () => {
      if (!this.isSynthesizedPlatformStream && !this.isChromelessStream) {
        this.isPlaying = true;
        if (this.centerPlayBtn) this.centerPlayBtn.classList.add("opacity-0", "pointer-events-none");
        this.updatePlayBtnIcons(true);
      }
    });

    this.video.addEventListener("pause", () => {
      if (!this.isSynthesizedPlatformStream && !this.isChromelessStream) {
        this.isPlaying = false;
        if (this.centerPlayBtn) this.centerPlayBtn.classList.remove("opacity-0", "pointer-events-none");
        this.updatePlayBtnIcons(false);
      }
    });

    this.video.addEventListener("timeupdate", () => {
      if (!this.isSynthesizedPlatformStream && !this.isChromelessStream) {
        const dur =
          this.video.duration && !isNaN(this.video.duration) && isFinite(this.video.duration) && this.video.duration > 30
            ? this.video.duration
            : this.virtualDuration || 60;
        this.handleTimeTick(this.video.currentTime, dur);
      }
    });

    if (this.volumeBtn) {
      this.volumeBtn.addEventListener("click", () => {
        const sliderBox = document.getElementById("volume-slider-box");
        if (sliderBox && window.matchMedia("(hover: none)").matches) {
          sliderBox.classList.toggle("active");
        }
        this.toggleMute();
      });
    }

    if (this.volumeSlider) {
      this.volumeSlider.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value);
        this.setVolume(val);
      });
    }

    if (this.fullscreenBtn) {
      this.fullscreenBtn.addEventListener("click", () => this.toggleFullscreen());
    }

    if (this.settingsBtn) {
      this.settingsBtn.addEventListener("click", () => this.openSettingsModal());
    }
    document.getElementById("close-settings-modal")?.addEventListener("click", () => {
      document.getElementById("player-settings-modal")?.classList.add("hidden");
      document.getElementById("player-settings-modal")?.classList.remove("flex");
    });

    const speedButtons = document.querySelectorAll(".speed-btn");
    speedButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        speedButtons.forEach((b) =>
          b.classList.remove("active", "border", "border-purple-500", "bg-purple-900/50", "text-white", "font-bold")
        );
        btn.classList.add("active", "border", "border-purple-500", "bg-purple-900/50", "text-white", "font-bold");
        const speed = parseFloat(btn.dataset.speed || "1.0");
        this.setPlaybackSpeed(speed);
      });
    });

    const loopToggle = document.getElementById("player-loop-toggle");
    if (loopToggle) {
      loopToggle.addEventListener("change", (e) => {
        this.video.loop = e.target.checked;
      });
    }

    const pipBtn = document.getElementById("pip-toggle-btn");
    if (pipBtn) {
      pipBtn.addEventListener("click", async () => {
        try {
          if (document.pictureInPictureElement) {
            await document.exitPictureInPicture();
          } else if (this.video && this.video.requestPictureInPicture) {
            await this.video.requestPictureInPicture();
          }
        } catch (err) {
          console.warn("PiP error:", err);
        }
      });
    }

    if (this.qualityBadge) {
      this.qualityBadge.addEventListener("click", () => this.openVideoInfoModal());
    }
    document.getElementById("close-video-info-modal")?.addEventListener("click", () => {
      document.getElementById("video-info-modal")?.classList.add("hidden");
      document.getElementById("video-info-modal")?.classList.remove("flex");
    });

    const stepBackBtn = document.getElementById("timeline-step-back");
    if (stepBackBtn) {
      stepBackBtn.addEventListener("click", () => {
        this.seekTo(Math.max(0, this.getCurrentTime() - 2));
      });
    }

    const stepForwardBtn = document.getElementById("timeline-step-forward");
    if (stepForwardBtn) {
      stepForwardBtn.addEventListener("click", () => {
        this.seekTo(Math.min(this.getDuration() || 60, this.getCurrentTime() + 2));
      });
    }

    window.addEventListener("resize", () => {
      if (window.subtitlesInstance) {
        window.subtitlesInstance.applySubtitleStyling();
      }
    });

    window.addEventListener("keydown", (e) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;

      if (e.code === "Space") {
        e.preventDefault();
        this.togglePlay();
      } else if (e.code === "KeyJ") {
        this.seekTo(Math.max(0, this.getCurrentTime() - 5));
      } else if (e.code === "KeyL") {
        this.seekTo(Math.min(this.getDuration() || 60, this.getCurrentTime() + 5));
      } else if (e.code === "KeyF") {
        this.toggleFullscreen();
      } else if (e.code === "KeyM") {
        this.toggleMute();
      }
    });
  }

  getOrCreateTtsAudio() {
    if (!this.ttsAudioEl) {
      this.ttsAudioEl = document.createElement("audio");
      this.ttsAudioEl.id = "studio-tts-audio";
      this.ttsAudioEl.setAttribute("referrerpolicy", "no-referrer");
      this.ttsAudioEl.preload = "auto";
    }
    return this.ttsAudioEl;
  }

  getOrCreateYtAudio() {
    if (!this.ytAudioEl) {
      this.ytAudioEl = document.createElement("audio");
      this.ytAudioEl.id = "studio-yt-audio";
      this.ytAudioEl.preload = "auto";
    }
    return this.ytAudioEl;
  }

  getCurrentTime() {
    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.getCurrentTime === "function") {
      try {
        return this.ytPlayer.getCurrentTime() || this.virtualCurrentTime || 0;
      } catch (e) {}
    }
    if (this.isSynthesizedPlatformStream || this.isChromelessStream) {
      return this.virtualCurrentTime || 0;
    }
    return this.video ? this.video.currentTime || 0 : 0;
  }

  getDuration() {
    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.getDuration === "function") {
      try {
        const d = this.ytPlayer.getDuration();
        if (d && d > 0) return d;
      } catch (e) {}
    }
    if (this.isSynthesizedPlatformStream || this.isChromelessStream) {
      return this.virtualDuration || 60;
    }
    return this.video && this.video.duration && !isNaN(this.video.duration) && isFinite(this.video.duration) && this.video.duration > 30
      ? this.video.duration
      : this.virtualDuration || window.timelineInstance?.duration || 60;
  }

  seekTo(seconds) {
    const dur = this.getDuration() || 60;
    const target = Math.max(0, Math.min(dur, seconds));
    this.virtualCurrentTime = target;
    this.lastSpokenCueId = -1;

    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.seekTo === "function") {
      try {
        this.ytPlayer.seekTo(target, true);
      } catch (e) {}
      this.handleTimeTick(target, dur);
    } else if (this.isSynthesizedPlatformStream) {
      if (this.video && this.video.duration && isFinite(this.video.duration) && this.video.duration > 0) {
        try {
          this.video.currentTime = target % this.video.duration;
        } catch (e) {}
      }
      if (this.ytAudioEl && this.ytAudioEl.src && this.ytAudioEl.duration > 0) {
        try {
          this.ytAudioEl.currentTime = target;
        } catch (e) {}
      }
      this.handleTimeTick(target, dur);
    } else if (this.video) {
      try {
        this.video.currentTime = target;
      } catch (e) {}
      this.handleTimeTick(target, dur);
    }
  }

  setPlaybackSpeed(speed) {
    this.playbackSpeed = speed || 1.0;
    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.setPlaybackRate === "function") {
      try {
        this.ytPlayer.setPlaybackRate(this.playbackSpeed);
      } catch (e) {}
    }
    if (this.video) {
      try {
        this.video.playbackRate = this.playbackSpeed;
      } catch (e) {}
    }
    if (this.ytAudioEl) {
      try {
        this.ytAudioEl.playbackRate = this.playbackSpeed;
      } catch (e) {}
    }
    if (this.ttsAudioEl) {
      try {
        this.ttsAudioEl.playbackRate = Math.min(2.0, Math.max(0.8, this.playbackSpeed));
      } catch (e) {}
    }
  }

  buildStreamSourcesList(ytId, directMp4Url, candidateMp4Urls) {
    const sources = [];
    // Source 1: Native Moving MP4 Video inside <video id="main-video"> (guaranteed instant playback, zero static pictures!)
    sources.push({ type: "native_moving_mp4", label: "مشغل MP4 الأساسي (فيديو متحرك)" });

    if (directMp4Url && !directMp4Url.startsWith("blob:")) {
      sources.push({ type: "mp4", label: "دفق MP4 مباشر (سريع)", url: directMp4Url });
    }
    if (ytId) {
      if (Array.isArray(candidateMp4Urls)) {
        candidateMp4Urls.forEach((u, i) => {
          if (u && !sources.some((s) => s.url === u)) {
            sources.push({ type: "mp4", label: `سيرفر MP4 مباشر #${i + 1}`, url: u });
          }
        });
      }
      sources.push({ type: "chromeless", label: "بث مباشر HD (خارجي)", ytId });
    }
    return sources;
  }

  cycleStreamSource() {
    if (!this.streamSources || this.streamSources.length === 0) return;
    this.currentSourceIndex = (this.currentSourceIndex + 1) % this.streamSources.length;
    const chosen = this.streamSources[this.currentSourceIndex];
    this.activateStreamSource(chosen, false);
    if (window.timelineInstance) {
      window.timelineInstance.showToast(`🔄 تم التبديل إلى: ${chosen.label}`);
    }
  }

  loadDownloadedPlatformVideo({
    ytId,
    title,
    uploader,
    duration,
    isShort,
    directMp4Url,
    directAudioUrl,
    candidateMp4Urls,
    blobUrl,
    sceneImages,
  }) {
    this.ytVideoId = ytId || null;
    this.videoTitle = title || "";
    this.videoUploader = uploader || "YouTube";
    this.virtualDuration = Number(duration) > 0 ? Number(duration) : isShort ? 35 : 90;
    this.virtualCurrentTime = 0;
    this.isShortVideo = Boolean(isShort);
    this.directAudioUrl = directAudioUrl || "";
    this.fallbackBlobUrl = blobUrl || "";
    this.previewSegmentBounds = null;
    this.jumpCutSegments = null;
    this.sceneImages = Array.isArray(sceneImages) ? sceneImages : [];

    this.hideEmptyState();
    if (this.sourceSwitchBtn) {
      this.sourceSwitchBtn.classList.remove("hidden");
      this.sourceSwitchBtn.classList.add("flex");
    }

    this.streamSources = this.buildStreamSourcesList(ytId, directMp4Url, candidateMp4Urls);
    // If a verified external full-length directMp4Url was resolved, try it first; otherwise start immediately on native_moving_mp4!
    const directIdx = directMp4Url && !directMp4Url.startsWith("blob:")
      ? this.streamSources.findIndex((s) => s.type === "mp4" && s.url === directMp4Url)
      : 0;
    this.currentSourceIndex = directIdx >= 0 ? directIdx : 0;

    this.activateStreamSource(this.streamSources[this.currentSourceIndex], true);
  }

  activateStreamSource(sourceObj, allowAutoFailover = true) {
    if (!sourceObj) return;
    if (this.sourceLabel) {
      this.sourceLabel.innerText = sourceObj.label;
    }

    this.cleanupActiveEngines();

    if (sourceObj.type === "mp4" && sourceObj.url) {
      this.tryDirectMp4Playback(sourceObj.url, allowAutoFailover);
    } else if (sourceObj.type === "chromeless" && sourceObj.ytId) {
      this.tryChromelessStreamPlayback(sourceObj.ytId, allowAutoFailover);
    } else {
      this.activateNativeMovingMp4Mode();
    }
  }

  /**
   * Primary Native Moving MP4 Mode:
   * Plays the real moving H.264 MP4 video directly inside <video id="main-video"> (NEVER covered by static pictures!),
   * while synchronizing the full timeline duration (e.g. 09:04 = 544s) and real spoken audio.
   */
  activateNativeMovingMp4Mode() {
    this.cleanupActiveEngines();
    this.isSynthesizedPlatformStream = true;
    this.isChromelessStream = false;

    if (this.sourceLabel) {
      this.sourceLabel.innerText = "مشغل MP4 الأساسي (فيديو متحرك)";
    }

    // Ensure static image canvas is HIDDEN so <video id="main-video"> is 100% visible!
    const studioCanvas = document.getElementById("native-studio-canvas");
    if (studioCanvas) {
      studioCanvas.classList.add("hidden");
    }

    if (this.video) {
      this.video.classList.remove("hidden");
      this.video.loop = true;
      if (this.fallbackBlobUrl && this.video.src !== this.fallbackBlobUrl) {
        this.video.src = this.fallbackBlobUrl;
        this.video.load();
      }
    }

    if (this.directAudioUrl) {
      const ytAud = this.getOrCreateYtAudio();
      if (ytAud.src !== this.directAudioUrl) {
        ytAud.src = this.directAudioUrl;
        ytAud.load();
      }
    }

    this.updateTimeDisplay(this.virtualCurrentTime, this.virtualDuration);
    this.startSynthesizedPlayback();
  }

  tryDirectMp4Playback(mp4Url, allowAutoFailover) {
    this.isSynthesizedPlatformStream = false;
    this.isChromelessStream = false;
    if (!this.video) return;

    this.video.classList.remove("hidden");
    this.video.loop = false;
    this.video.removeAttribute("crossorigin");

    let settled = false;
    const failTimer = setTimeout(() => {
      if (settled) return;
      settled = true;
      if (allowAutoFailover) {
        this.activateNativeMovingMp4Mode();
      }
    }, 3500);

    const onLoaded = () => {
      if (settled) return;
      settled = true;
      clearTimeout(failTimer);
      this.video.removeEventListener("loadeddata", onLoaded);
      this.video.removeEventListener("canplay", onLoaded);
      this.video.removeEventListener("error", onErr);
      if (this.virtualCurrentTime > 1 && this.video.duration > this.virtualCurrentTime) {
        try {
          this.video.currentTime = this.virtualCurrentTime;
        } catch (e) {}
      }
      this.video.play().catch(() => {});
    };

    const onErr = () => {
      if (settled) return;
      settled = true;
      clearTimeout(failTimer);
      this.video.removeEventListener("loadeddata", onLoaded);
      this.video.removeEventListener("canplay", onLoaded);
      this.video.removeEventListener("error", onErr);
      if (allowAutoFailover) {
        this.activateNativeMovingMp4Mode();
      }
    };

    this.video.addEventListener("loadeddata", onLoaded);
    this.video.addEventListener("canplay", onLoaded);
    this.video.addEventListener("error", onErr);

    this.video.src = mp4Url;
    this.video.load();
    this.video.play().catch(() => {});
  }

  tryChromelessStreamPlayback(ytId, allowAutoFailover) {
    this.isSynthesizedPlatformStream = false;
    this.isChromelessStream = true;

    let streamWrap = document.getElementById("chromeless-stream-container");
    if (!streamWrap) {
      streamWrap = document.createElement("div");
      streamWrap.id = "chromeless-stream-container";
      streamWrap.className = "absolute inset-0 w-full h-full z-10 overflow-hidden bg-black hidden";
      const container = document.getElementById("player-container");
      if (container && this.video) {
        container.insertBefore(streamWrap, this.video.nextSibling);
      }
    }
    streamWrap.classList.remove("hidden");
    streamWrap.innerHTML = `
      <div class="w-full h-full relative overflow-hidden">
        <div id="chromeless-yt-target" class="w-full h-full scale-[1.03] pointer-events-none"></div>
        <div id="platform-stream-shield" class="absolute inset-0 z-10 cursor-pointer bg-transparent"></div>
      </div>
    `;

    streamWrap.querySelector("#platform-stream-shield")?.addEventListener("click", (e) => {
      e.stopPropagation();
      this.togglePlay();
    });

    let settled = false;
    const handleStreamFailure = () => {
      if (settled) return;
      settled = true;
      streamWrap.classList.add("hidden");
      streamWrap.innerHTML = "";
      this.activateNativeMovingMp4Mode();
    };

    const mountPlayer = () => {
      if (!window.YT || !window.YT.Player) {
        handleStreamFailure();
        return;
      }
      try {
        const pageOrigin =
          window.location && window.location.origin && window.location.origin.startsWith("http")
            ? window.location.origin
            : "https://www.youtube.com";

        this.ytPlayer = new window.YT.Player("chromeless-yt-target", {
          host: "https://www.youtube-nocookie.com",
          videoId: ytId,
          width: "100%",
          height: "100%",
          playerVars: {
            autoplay: 1,
            controls: 0,
            disablekb: 1,
            fs: 0,
            iv_load_policy: 3,
            modestbranding: 1,
            rel: 0,
            playsinline: 1,
            enablejsapi: 1,
            origin: pageOrigin,
            widget_referrer: "https://www.youtube.com",
          },
          events: {
            onReady: (ev) => {
              if (settled) return;
              settled = true;
              const iframeEl = streamWrap.querySelector("iframe");
              if (iframeEl) {
                iframeEl.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                iframeEl.classList.add("w-full", "h-full", "border-0", "pointer-events-none");
              }
              if (this.virtualCurrentTime > 1) {
                try {
                  ev.target.seekTo(this.virtualCurrentTime, true);
                } catch (e) {}
              }
              try {
                ev.target.playVideo();
              } catch (e) {}
              this.isPlaying = true;
              if (this.centerPlayBtn) this.centerPlayBtn.classList.add("opacity-0", "pointer-events-none");
              this.updatePlayBtnIcons(true);
              this.startChromelessPolling();
            },
            onStateChange: (ev) => {
              if (ev.data === 1) {
                this.isPlaying = true;
                if (this.centerPlayBtn) this.centerPlayBtn.classList.add("opacity-0", "pointer-events-none");
                this.updatePlayBtnIcons(true);
              } else if (ev.data === 2 || ev.data === 0) {
                this.isPlaying = false;
                if (this.centerPlayBtn) this.centerPlayBtn.classList.remove("opacity-0", "pointer-events-none");
                this.updatePlayBtnIcons(false);
              }
            },
            onError: () => {
              settled = false;
              handleStreamFailure();
            },
          },
        });
      } catch (e) {
        handleStreamFailure();
      }
    };

    if (window.YT && window.YT.Player) {
      mountPlayer();
    } else {
      const existingScript = document.getElementById("yt-iframe-api-loader");
      if (!existingScript) {
        const tag = document.createElement("script");
        tag.id = "yt-iframe-api-loader";
        tag.src = "https://www.youtube.com/iframe_api";
        tag.onerror = () => handleStreamFailure();
        document.head.appendChild(tag);
      }
      const prevCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (typeof prevCallback === "function") prevCallback();
        mountPlayer();
      };
      setTimeout(() => {
        if (!settled && (!window.YT || !window.YT.Player)) {
          handleStreamFailure();
        }
      }, 2800);
    }
  }

  startChromelessPolling() {
    if (this.ytPollTimer) clearInterval(this.ytPollTimer);
    this.ytPollTimer = setInterval(() => {
      if (!this.isChromelessStream) {
        clearInterval(this.ytPollTimer);
        return;
      }
      let cur = this.virtualCurrentTime;
      let dur = this.virtualDuration || 60;
      if (this.ytPlayer && typeof this.ytPlayer.getCurrentTime === "function") {
        try {
          cur = this.ytPlayer.getCurrentTime() || 0;
          const d = this.ytPlayer.getDuration();
          if (d && d > 0) dur = d;
        } catch (e) {}
      }
      this.virtualCurrentTime = cur;
      this.virtualDuration = dur;
      this.handleTimeTick(cur, dur);
    }, 180);
  }

  cleanupActiveEngines() {
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.ytPollTimer) {
      clearInterval(this.ytPollTimer);
      this.ytPollTimer = null;
    }
    if (this.ytPlayer && typeof this.ytPlayer.destroy === "function") {
      try {
        this.ytPlayer.destroy();
      } catch (e) {}
      this.ytPlayer = null;
    }
    const streamWrap = document.getElementById("chromeless-stream-container");
    if (streamWrap) {
      streamWrap.innerHTML = "";
      streamWrap.classList.add("hidden");
    }
    const studioCanvas = document.getElementById("native-studio-canvas");
    if (studioCanvas) {
      studioCanvas.classList.add("hidden");
    }
    this.stopSpokenTts();
  }

  startSynthesizedPlayback() {
    this.isPlaying = true;
    if (this.centerPlayBtn) this.centerPlayBtn.classList.add("opacity-0", "pointer-events-none");
    this.updatePlayBtnIcons(true);
    if (this.video && this.video.src) {
      this.video.play().catch(() => {});
    }
    if (this.ytAudioEl && this.ytAudioEl.src) {
      this.ytAudioEl.play().catch(() => {});
    }
    this.lastTickMs = performance.now();

    if (this.rafId) cancelAnimationFrame(this.rafId);
    const loop = (now) => {
      if (!this.isSynthesizedPlatformStream) return;
      const dt = Math.min(0.1, Math.max(0, (now - this.lastTickMs) / 1000));
      this.lastTickMs = now;

      if (this.isPlaying) {
        const dur = this.virtualDuration || 60;
        let nextTime = this.virtualCurrentTime + dt * (this.playbackSpeed || 1.0);
        if (nextTime >= dur) {
          nextTime = 0;
          this.lastSpokenCueId = -1;
        }
        this.virtualCurrentTime = nextTime;

        // Keep <video id="main-video"> actively playing the moving video!
        if (this.video && this.video.paused && this.video.src) {
          this.video.play().catch(() => {});
        }

        this.speakActiveSubtitleCue(nextTime);
        this.handleTimeTick(nextTime, dur);
      }
      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);
  }

  pauseSynthesizedPlayback() {
    this.isPlaying = false;
    if (this.centerPlayBtn) this.centerPlayBtn.classList.remove("opacity-0", "pointer-events-none");
    this.updatePlayBtnIcons(false);
    if (this.video) {
      try {
        this.video.pause();
      } catch (e) {}
    }
    if (this.ytAudioEl) {
      try {
        this.ytAudioEl.pause();
      } catch (e) {}
    }
    this.stopSpokenTts();
  }

  /**
   * Plays spoken Arabic/English voice synchronized with the active subtitle cue:
   *  1. If original YouTube audio stream (ytAudioEl) is playing, lets it play natively.
   *  2. Otherwise plays real spoken Arabic MP3 audio via <audio referrerpolicy="no-referrer"> (Google TTS MP3)
   *     plus Web Speech synthesis fallback so the user always hears natural spoken Arabic on Android & Desktop!
   */
  speakActiveSubtitleCue(currentTime) {
    if (this.video && (this.video.muted || this.video.volume === 0)) return;
    if (this.ytAudioEl && this.ytAudioEl.src && !this.ytAudioEl.paused && this.ytAudioEl.readyState >= 2) {
      return;
    }
    if (!window.subtitlesInstance || !window.subtitlesInstance.cues) return;

    const cue = window.subtitlesInstance.cues.find(
      (c) => currentTime >= c.start_sec && currentTime <= c.end_sec
    );
    if (!cue || cue.id === this.lastSpokenCueId) return;

    this.lastSpokenCueId = cue.id;
    const cleanText = String(cue.text || "").split("|")[0].trim();
    if (!cleanText) return;
    const hasAr = /[\u0600-\u06FF]/.test(cleanText);
    const tl = hasAr ? "ar" : "en";

    // Play real MP3 speech stream via <audio referrerpolicy="no-referrer"> (works in Android WebViews!)
    try {
      const ttsAudio = this.getOrCreateTtsAudio();
      ttsAudio.volume = this.video ? this.video.volume : 1.0;
      ttsAudio.playbackRate = Math.min(2.0, Math.max(0.85, (this.playbackSpeed || 1.0) * 1.12));
      ttsAudio.src = `https://translate.googleapis.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${tl}&q=${encodeURIComponent(
        cleanText
      )}`;
      ttsAudio.play().catch(() => {
        // Fallback to Web Speech API if translate_tts is blocked
        if (window.speechSynthesis) {
          try {
            window.speechSynthesis.cancel();
            const utter = new SpeechSynthesisUtterance(cleanText);
            utter.lang = hasAr ? "ar-SA" : "en-US";
            utter.rate = Math.min(2.0, Math.max(0.85, (this.playbackSpeed || 1.0) * 1.1));
            utter.volume = this.video ? this.video.volume : 1.0;
            window.speechSynthesis.speak(utter);
          } catch (e) {}
        }
      });
    } catch (e) {}
  }

  stopSpokenTts() {
    try {
      if (this.ttsAudioEl) {
        this.ttsAudioEl.pause();
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {}
  }

  renderSynthesizedFrame() {
    // Static canvas overlay is intentionally disabled when real moving MP4 video is in <video id="main-video">
  }

  handleTimeTick(cur, dur) {
    if (this.previewSegmentBounds) {
      if (cur < this.previewSegmentBounds.start || cur >= this.previewSegmentBounds.end) {
        this.seekTo(this.previewSegmentBounds.start);
        return;
      }
    }

    if (this.jumpCutSegments && this.jumpCutSegments.length > 0) {
      const inSpeech = this.jumpCutSegments.some((seg) => cur >= seg.start && cur <= seg.end);
      if (!inSpeech) {
        const nextSeg = this.jumpCutSegments.find((seg) => seg.start > cur);
        if (nextSeg) {
          this.seekTo(nextSeg.start);
          return;
        }
      }
    }

    this.updateTimeDisplay(cur, dur);
    if (window.timelineInstance && !window.timelineInstance.isDraggingPlayhead) {
      if (dur > 0 && window.timelineInstance.duration !== dur) {
        window.timelineInstance.duration = dur;
        window.timelineInstance.renderRuler();
      }
      window.timelineInstance.setTime(cur);
    }
    if (window.subtitlesInstance) {
      window.subtitlesInstance.renderActiveSubtitle(cur);
    }
  }

  switchToNativeVideoMode() {
    this.isSynthesizedPlatformStream = false;
    this.isChromelessStream = false;
    this.previewSegmentBounds = null;
    this.cleanupActiveEngines();
    if (this.video) {
      this.video.classList.remove("hidden");
    }
  }

  togglePlay() {
    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.getPlayerState === "function") {
      try {
        const state = this.ytPlayer.getPlayerState();
        if (state === 1) {
          this.ytPlayer.pauseVideo();
          this.isPlaying = false;
          if (this.centerPlayBtn) this.centerPlayBtn.classList.remove("opacity-0", "pointer-events-none");
        } else {
          this.ytPlayer.playVideo();
          this.isPlaying = true;
          if (this.centerPlayBtn) this.centerPlayBtn.classList.add("opacity-0", "pointer-events-none");
        }
        this.updatePlayBtnIcons(this.isPlaying);
        return;
      } catch (e) {}
    }

    if (this.isSynthesizedPlatformStream) {
      if (this.isPlaying) {
        this.pauseSynthesizedPlayback();
      } else {
        this.startSynthesizedPlayback();
      }
      return;
    }

    if (!this.video) return;
    if (this.video.paused) {
      this.video.play().catch(() => {});
    } else {
      this.video.pause();
    }
  }

  toggleMute() {
    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.isMuted === "function") {
      try {
        if (this.ytPlayer.isMuted()) {
          this.ytPlayer.unMute();
          this.setVolume(this.previousVolume || 1.0);
        } else {
          this.ytPlayer.mute();
          this.updateVolumeIcon(0);
        }
      } catch (e) {}
      return;
    }

    if (this.video.muted || this.video.volume === 0) {
      this.video.muted = false;
      this.setVolume(this.previousVolume || 1.0);
    } else {
      this.previousVolume = this.video.volume;
      this.video.muted = true;
      this.setVolume(0);
      this.stopSpokenTts();
    }
  }

  setVolume(val) {
    val = Math.max(0, Math.min(1, val));
    if (this.isChromelessStream && this.ytPlayer && typeof this.ytPlayer.setVolume === "function") {
      try {
        this.ytPlayer.setVolume(Math.round(val * 100));
        if (val === 0) this.ytPlayer.mute();
        else this.ytPlayer.unMute();
      } catch (e) {}
    }
    if (this.video) {
      this.video.volume = val;
      this.video.muted = val === 0;
    }
    if (this.ytAudioEl) {
      this.ytAudioEl.volume = val;
      this.ytAudioEl.muted = val === 0;
    }
    if (this.ttsAudioEl) {
      this.ttsAudioEl.volume = val;
      this.ttsAudioEl.muted = val === 0;
    }
    if (this.volumeSlider) {
      this.volumeSlider.value = val;
    }
    this.updateVolumeIcon(val);
  }

  updateVolumeIcon(val) {
    if (!this.volumeBtn) return;
    if (val === 0 || (!this.isChromelessStream && this.video?.muted)) {
      this.volumeBtn.innerHTML = `<span id="volume-icon" class="text-red-400">🔇</span>`;
    } else if (val < 0.5) {
      this.volumeBtn.innerHTML = `<span id="volume-icon">🔉</span>`;
    } else {
      this.volumeBtn.innerHTML = `<span id="volume-icon">🔊</span>`;
    }
  }

  updatePlayBtnIcons(isPlaying) {
    if (this.timelinePlayBtn) {
      this.timelinePlayBtn.innerHTML = isPlaying ? "⏸" : "▶";
    }
  }

  updateTimeDisplay(curOverride, durOverride) {
    if (!this.timeDisplay) return;
    if (!window.currentVideoId) {
      this.timeDisplay.innerText = "00:00 / 00:00";
      return;
    }
    const cur = curOverride !== undefined ? curOverride : this.getCurrentTime();
    const dur = durOverride !== undefined ? durOverride : this.getDuration();
    this.timeDisplay.innerText = `${this.formatTime(cur)} / ${this.formatTime(dur)}`;
  }

  showEmptyState() {
    this.switchToNativeVideoMode();
    const emptyState = document.getElementById("empty-player-state");
    const bottomControls = document.getElementById("player-bottom-controls");
    const qualityBadge = document.getElementById("player-quality-badge");
    const delBtn = document.getElementById("player-delete-video-btn");
    const customTextBanner = document.getElementById("player-custom-text-banner");

    if (emptyState) emptyState.classList.remove("hidden");
    if (this.video) {
      this.video.classList.add("hidden");
      this.video.pause();
      this.video.removeAttribute("src");
      this.video.load();
    }
    this.isPlaying = false;
    this.updatePlayBtnIcons(false);
    this.resetFilters();

    if (this.centerPlayBtn) this.centerPlayBtn.classList.add("hidden");
    if (bottomControls) bottomControls.classList.add("hidden");
    if (qualityBadge) qualityBadge.classList.add("hidden");
    if (this.sourceSwitchBtn) this.sourceSwitchBtn.classList.add("hidden");
    if (delBtn) delBtn.classList.add("hidden");
    if (customTextBanner) customTextBanner.classList.add("hidden");
    if (this.subtitlesOverlay) {
      this.subtitlesOverlay.innerText = "";
      this.subtitlesOverlay.classList.add("hidden");
    }
    this.updateTimeDisplay(0, 0);
  }

  hideEmptyState() {
    const emptyState = document.getElementById("empty-player-state");
    const bottomControls = document.getElementById("player-bottom-controls");
    const qualityBadge = document.getElementById("player-quality-badge");
    const delBtn = document.getElementById("player-delete-video-btn");

    if (emptyState) emptyState.classList.add("hidden");
    if (this.video) this.video.classList.remove("hidden");
    if (this.centerPlayBtn) {
      this.centerPlayBtn.classList.remove("hidden");
    }
    if (bottomControls) {
      bottomControls.classList.remove("hidden");
      bottomControls.classList.add("flex");
    }
    if (qualityBadge) {
      qualityBadge.classList.remove("hidden");
      qualityBadge.classList.add("flex");
    }
    if (delBtn) {
      delBtn.classList.remove("hidden");
      delBtn.classList.add("flex");
    }
    this.updateTimeDisplay();
  }

  formatTime(seconds) {
    if (isNaN(seconds) || seconds < 0) seconds = 0;
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    }
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  }

  toggleFullscreen() {
    const container = document.getElementById("player-container");
    if (!document.fullscreenElement) {
      if (container && container.requestFullscreen) {
        container.requestFullscreen();
      } else if (this.video && this.video.webkitEnterFullscreen) {
        this.video.webkitEnterFullscreen();
      }
    } else if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  }

  openSettingsModal() {
    const modal = document.getElementById("player-settings-modal");
    if (modal) {
      modal.classList.remove("hidden");
      modal.classList.add("flex");
    }
  }

  async openVideoInfoModal() {
    if (!window.currentVideoId) return;

    const modal = document.getElementById("video-info-modal");
    if (!modal) return;
    modal.classList.remove("hidden");
    modal.classList.add("flex");

    const resEl = document.getElementById("spec-resolution");
    const durEl = document.getElementById("spec-duration");
    const fpsEl = document.getElementById("spec-fps");

    const dur = this.getDuration();
    if (durEl) durEl.innerText = this.formatTime(dur);

    if (resEl) resEl.innerText = window.currentVideoMeta?.info?.resolution || "1920x1080 (Full HD)";
    if (fpsEl) fpsEl.innerText = "30.0 FPS";
  }

  applyFilter(type, value) {
    this.filters[type] = value;
    const filterString = `brightness(${this.filters.brightness}) contrast(${this.filters.contrast}) saturate(${this.filters.saturation}) sepia(${this.filters.sepia}%) blur(${this.filters.blur}px)`;
    if (this.video) this.video.style.filter = filterString;
    const streamWrap = document.getElementById("chromeless-stream-container");
    if (streamWrap) streamWrap.style.filter = filterString;
  }

  resetFilters() {
    this.filters = { brightness: 1.0, contrast: 1.0, saturation: 1.0, sepia: 0, blur: 0 };
    if (this.video) this.video.style.filter = "none";
    const streamWrap = document.getElementById("chromeless-stream-container");
    if (streamWrap) streamWrap.style.filter = "none";
  }
}

window.VideoPlayer = VideoPlayer;
